/*
 sql卸载文件
*/
DROP TABLE IF EXISTS `db_example_category`;
DROP TABLE IF EXISTS `db_example_news`;