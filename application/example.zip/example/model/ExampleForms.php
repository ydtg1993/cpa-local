<?php

namespace app\example\model;

use think\Model;

class ExampleForms extends Model
{
    //
}
